
function validation(){

    var subs=document.getElementById("subs");
    var email=document.getElementById("email").value;

    var text=document.getElementById("text");
    var pattern=/^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if(email.match(pattern))
    {
        subs.classList.add("valid");
        subs.classList.remove("Invalid");
        text.innerHTML="Your email is correct";
        text.style.color= "#00ff00";
    }
    else{
        subs.classList.remove("valid");
        subs.classList.add("Invalid");
        text.innerHTML="Invalid email";
        text.style.color= "#ff0000";
    }
    
    if(email == "")
    {
        subs.classList.remove("valid");
        subs.classList.remove("Invalid");
        text.innerHTML = "";
        text.style.color = "#00ff00";
    }
}


function validation1(){

    var lg1=document.getElementById("lg1");
    var email=document.getElementById("email").value;

    var text=document.getElementById("text");
    var pattern=/^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if(email.match(pattern))
    {
        lg1.classList.add("valid");
        lg1.classList.remove("Invalid");
        text.innerHTML="Your email is correct";
        text.style.color= "#00ff00";
    }
    else{
        lg1.classList.remove("valid");
        lg1.classList.add("Invalid");
        text.innerHTML="Invalid email";
        text.style.color= "#ff0000";
    }
    
    if(email == "")
    {
        lg1.classList.remove("valid");
        lg1.classList.remove("Invalid");
        text.innerHTML = "";
        text.style.color = "#00ff00";
    }
}

// function adminvalid(){

//     var subs=document.getElementById("subs");
//     var email=document.getElementById("email").value;

//     var text=document.getElementById("text");
//     var pattern=/^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

//     if(email.match(pattern))
//     {
//         subs.classList.add("valid");
//         subs.classList.remove("Invalid");
//         text.innerHTML="Your email is correct";
//         text.style.color= "#00ff00";
//     }