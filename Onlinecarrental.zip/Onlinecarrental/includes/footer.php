
<?php

if(isset($_POST['emailsubscibe']))
{

  $subscriberemail=$_POST['subscriberemail'];

  // e-mail ->> validate function
  function is_email($subscriberemail) 
  {
    return(preg_match("/^[-_.[:alnum:]]+@((([[:alnum:]]|[[:alnum:]][[:alnum:]-]*[[:alnum:]])\.)+(ad|ae|aero|af|ag|ai|al|am|an|ao|aq|ar|arpa|as|at|au|aw|az|ba|bb|bd|be|bf|bg|bh|bi|biz|bj|bm|bn|bo|br|bs|bt|bv|bw|by|bz|ca|cc|cd|cf|cg|ch|ci|ck|cl|cm|cn|co|com|coop|cr|cs|cu|cv|cx|cy|cz|de|dj|dk|dm|do|dz|ec|edu|ee|eg|eh|er|es|et|eu|fi|fj|fk|fm|fo|fr|ga|gb|gd|ge|gf|gh|gi|gl|gm|gn|gov|gp|gq|gr|gs|gt|gu|gw|gy|hk|hm|hn|hr|ht|hu|id|ie|il|in|info|int|io|iq|ir|is|it|jm|jo|jp|ke|kg|kh|ki|km|kn|kp|kr|kw|ky|kz|la|lb|lc|li|lk|lr|ls|lt|lu|lv|ly|ma|mc|md|mg|mh|mil|mk|ml|mm|mn|mo|mp|mq|mr|ms|mt|mu|museum|mv|mw|mx|my|mz|na|name|nc|ne|net|nf|ng|ni|nl|no|np|nr|nt|nu|nz|om|org|pa|pe|pf|pg|ph|pk|pl|pm|pn|pr|pro|ps|pt|pw|py|qa|re|ro|ru|rw|sa|sb|sc|sd|se|sg|sh|si|sj|sk|sl|sm|sn|so|sr|st|su|sv|sy|sz|tc|td|tf|tg|th|tj|tk|tm|tn|to|tp|tr|tt|tv|tw|tz|ua|ug|uk|um|us|uy|uz|va|vc|ve|vg|vi|vn|vu|wf|ws|ye|yt|yu|za|zm|zw)$|(([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5])\.){3}([0-9][0-9]?|[0-1][0-9][0-9]|[2][0-4][0-9]|[2][5][0-5]))$/i" ,$subscriberemail));
  }

  if ( is_email($_POST['subscriberemail']) == false ) 
  {
    echo "<script>alert('Cannot subscribe ,Invalid E-mail.');</script>";
  }

  
  else if( is_email($_POST['subscriberemail']) == true )
  {

    $sql ="SELECT SubscriberEmail FROM tblsubscribers WHERE SubscriberEmail=:subscriberemail";
    $query= $dbh -> prepare($sql);
    $query-> bindParam(':subscriberemail', $subscriberemail, PDO::PARAM_STR);
    $query-> execute();
    $results = $query -> fetchAll(PDO::FETCH_OBJ);
    $cnt=1;

        if($query -> rowCount() > 0)
        {
        echo "<script>alert('Already Subscribed.');</script>";
        }
        else
          {
            $sql="INSERT INTO  tblsubscribers(SubscriberEmail) VALUES(:subscriberemail)";
            $query = $dbh->prepare($sql);
            $query->bindParam(':subscriberemail',$subscriberemail,PDO::PARAM_STR);
            $query->execute();
            $lastInsertId = $dbh->lastInsertId();

                if($lastInsertId)
                {
                echo "<script>alert('Subscribed successfully.');</script>";
                }
                else
                {
                echo "<script>alert('Something went wrong. Please try again');</script>";
                }
                    
          }
    }
  
}
?>


<footer>
  <div class="footer-top">
    <div class="container">
      <div class="row">

        <div class="col-md-6">
          <h6>About Us</h6>
          <ul>

            <li><a href="admin/">Admin Login</a></li>
            <li><a href="page.php?type=aboutus">About Us</a></li>
            <li><a href="page.php?type=faqs">FAQs</a></li>
            <li><a href="page.php?type=privacy">Privacy</a></li>
            <li><a href="page.php?type=terms">Terms of use</a></li>
               
          </ul>
        </div>

        <div class="col-md-3 col-sm-6">
          <h6>Subscribe Newsletter</h6>
          <div class="newsletter-form">

            <form id="subs" method="post">
              <div class="form-group">
                <input type="text" name="subscriberemail" id="email" class="form-control newsletter-input" required placeholder="Enter Email Address" onkeydown="validation()" >
                <span id="text" style=":before{content='';}"></span>
              </div>
              <button type="submit" name="emailsubscibe" class="btn btn-block">Subscribe <span class="angle_arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></span></button>
            </form>
            
            <p class="subscribed-text">*We send great deals and latest auto news to our subscribed users every week.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-md-push-6 text-right">
          <div class="footer_widget">
            <p>Connect with Us:</p>
            <ul>

                <li><a href="https://facebook.com/" target="blank"><i class="fa fa-facebook-square" aria-hidden="true"></i></a></li>
                <li><a href="https://twitter.com/" target="blank"><i class="fa fa-twitter-square" aria-hidden="true"></i></a></li>
                <li><a href="https://linkedin.com/" target="blank"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a></li>
                <li><a href="https://googleplus.com/" target="blank"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a></li>
                <li><a href="https://instagram.com/" target="blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                <li><a href="https://youtube.com/" target="blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>

            </ul>
          </div>
        </div>
        <div class="col-md-6 col-md-pull-6">
          <p class="copy-right">&copy;2021 All Rights Reserved</p><p> Online Car Rental Portal.</p><p>-&nbsp;<a href="https:///" target="blank">VHCN </a>group&nbsp;-</p>
        </div>
      </div>
    </div>
  </div>
</footer>
